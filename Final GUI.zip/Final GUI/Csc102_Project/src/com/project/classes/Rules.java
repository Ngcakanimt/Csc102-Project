package com.project.classes;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Rules extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Rules frame = new Rules();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Rules() {
		setTitle("Crazy 8");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 2100, 701);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 128, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Rules & how to play");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 44));
		lblNewLabel.setBounds(384, 11, 523, 65);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("back");
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setBackground(Color.BLACK);
		btnNewButton.setFont(new Font("Stencil", Font.PLAIN, 20));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				contentPane.setVisible(false);
				dispose();
				Welcome.main(null); 
			}
		});
		btnNewButton.setBounds(489, 496, 129, 44);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("next");
		btnNewButton_1.setForeground(Color.WHITE);
		btnNewButton_1.setBackground(Color.BLACK);
		btnNewButton_1.setFont(new Font("Stencil", Font.PLAIN, 20));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				contentPane.setVisible(false);
				dispose();
				Menu.main(null); 
			}
		});
		btnNewButton_1.setBounds(869, 496, 115, 44);
		contentPane.add(btnNewButton_1);
		
		JTextArea txtrMustPlay = new JTextArea();
		txtrMustPlay.setEditable(false);
		txtrMustPlay.setFont(new Font("Times New Roman", Font.BOLD, 32));
		txtrMustPlay.setForeground(new Color(255, 250, 250));
		txtrMustPlay.setBackground(new Color(0, 128, 0));
		txtrMustPlay.setText("# Must play a card that is the same number or symbol of the \r\n   card on the deck\r\n# An eight of any suit can be played on anything\r\n# If player plays a two , next player draws two cards\r\n# If jack is played, next player is skipped\r\n# The buttons on this game tend to be as crazy as the game \r\n so move you mouse around in order to find them\r\n# Max of 3 players can play\r\n# HAVE FUN!");
		txtrMustPlay.setBounds(372, 78, 1057, 346);
		contentPane.add(txtrMustPlay);
	}
}
