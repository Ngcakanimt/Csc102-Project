package com.project.classes;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.Image;

import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.UIManager;

public class Welcome {

	private JFrame frmCrazy; //attribute 
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {    
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Welcome window = new Welcome();
					window.frmCrazy.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Welcome() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmCrazy = new JFrame();
		frmCrazy.setTitle("Crazy 8");
		frmCrazy.getContentPane().setBackground(Color.BLACK);
		frmCrazy.setBounds(0, 0, 2100, 701);
		frmCrazy.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmCrazy.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(0, 0, 2100, 701);
		Image im = new ImageIcon(this.getClass().getResource("/Welcome.jpg")).getImage();
		lblNewLabel.setIcon(new ImageIcon(im));
		frmCrazy.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Start");
		btnNewButton.setForeground(Color.BLACK);
		btnNewButton.setFont(new Font("Stencil", Font.PLAIN, 23));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmCrazy.setVisible(false);
				
				Rules.main(null);
			}
		});
		
		btnNewButton.setBounds(575, 257, 200, 65);
		frmCrazy.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Exit");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int p = JOptionPane.showConfirmDialog(null, "Are you sure you want to quit?","Select and option...", JOptionPane.YES_NO_OPTION);
				
				if(p == JOptionPane.YES_OPTION) {
					
					System.exit(0);
				}
				
				
			}
		});
	
		btnNewButton_1.setForeground(Color.BLACK);
		btnNewButton_1.setFont(new Font("Stencil", Font.PLAIN, 23));
		btnNewButton_1.setBounds(575, 345, 200, 65);
		frmCrazy.getContentPane().add(btnNewButton_1);
	}
	}

