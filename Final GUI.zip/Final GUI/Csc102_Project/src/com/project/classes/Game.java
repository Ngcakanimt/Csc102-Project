package com.project.classes;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.EventQueue;
import javax.swing.SwingConstants;
import java.awt.Dialog;
import javax.swing.JOptionPane;

public class Game extends JFrame  {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(int n) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Game frame = new Game(n);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Game(int n) {
		setBackground(new Color(51, 153, 153));
		setTitle("Crazy 8");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 2100, 800);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 102, 102));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(61, 196, 256, 182);
		Image img=  new ImageIcon(this.getClass().getResource("/SideBack.jpg")).getImage();
		lblNewLabel.setIcon(new ImageIcon(img));
		
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setBounds(568, 446, 183, 235);
		Image im=  new ImageIcon(this.getClass().getResource("/BackDesign.jpg")).getImage();
		lblNewLabel_1.setIcon(new ImageIcon(im));
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setBounds(970, 196, 256, 182);
		Image ime=  new ImageIcon(this.getClass().getResource("/SideBack.jpg")).getImage();
		lblNewLabel_2.setIcon(new ImageIcon(ime));
		
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setBounds(435, 89, 183, 256);
		Image in=  new ImageIcon(this.getClass().getResource("/BackDesign.jpg")).getImage();
		lblNewLabel_3.setIcon(new ImageIcon(in));
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setBounds(706, 89, 183, 256);
		Image ie=  new ImageIcon(this.getClass().getResource("/HQ.jpg")).getImage();
		lblNewLabel_4.setIcon(new ImageIcon(ie));
		contentPane.add(lblNewLabel_4);
		Menu mu= new Menu();
		if(n==2) {
			contentPane.add(lblNewLabel);	
		}
		 if(n==3) {
			contentPane.add(lblNewLabel);
			contentPane.add(lblNewLabel_2);
		}
		
		
		
	}
}
