package com.project.classes;

import com.sun.java.accessibility.util.GUIInitializedListener;

public class Start implements GUIInitializedListener {

}
