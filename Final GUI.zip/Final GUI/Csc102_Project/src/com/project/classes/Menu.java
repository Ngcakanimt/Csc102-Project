package com.project.classes;

//import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.JRadioButton;

public class Menu extends JFrame {
   private int num;
  
	/**
		 * @author user
		 *
		 */
	public class Start {

		/**
		 * @param args
		 */
		public static void main(String[] args) {
			// TODO Auto-generated method stub

		}

	}

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Menu frame = new Menu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Menu() {
		setTitle(" ");
		this.num=-1;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 2100, 701);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(0, 0, 2100, 701);
		Image img = new ImageIcon(this.getClass().getResource("/NumPlayers2.jpg")).getImage();
		lblNewLabel.setIcon(new ImageIcon(img));
		contentPane.add(lblNewLabel);
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("   2 Players");
		rdbtnNewRadioButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		rdbtnNewRadioButton.setBounds(98, 368, 204, 55);
		contentPane.add(rdbtnNewRadioButton);
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("   3 Players");
		rdbtnNewRadioButton_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		rdbtnNewRadioButton_1.setBounds(98, 489, 204, 55);
		contentPane.add(rdbtnNewRadioButton_1);
		
		ButtonGroup BuG= new ButtonGroup();
		BuG.add(rdbtnNewRadioButton_1);
		BuG.add(rdbtnNewRadioButton);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.setFont(new Font("Stencil", Font.PLAIN, 19));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				contentPane.setVisible(false);
				Welcome.main(null);
			}
		});
		btnNewButton.setBounds(205, 606, 129, 45);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Begin");
		btnNewButton_1.setFont(new Font("Stencil", Font.PLAIN, 18));
		btnNewButton_1.addActionListener(new ActionListener() {
			

			public void actionPerformed(ActionEvent e) {
				 
				if(rdbtnNewRadioButton_1.isSelected()== false&&rdbtnNewRadioButton.isSelected()== false) {
					JOptionPane.showMessageDialog(null, "Please choose one of the number of players Options.");	
					contentPane.setVisible(false);
					Menu.main(null);
				}
				if(rdbtnNewRadioButton_1.isSelected()== true||rdbtnNewRadioButton.isSelected()== true) {
					if(rdbtnNewRadioButton_1.isSelected()== true) {
					num=3;
					
					}
					else if(rdbtnNewRadioButton.isSelected()== true) {
					num=2;
					
					}
					contentPane.setVisible(false);
					Game.main(num);
					
				}
					
				
			}
		});
		btnNewButton_1.setBounds(555, 606, 122, 45);
		contentPane.add(btnNewButton_1);
		
	}
	public int choice() {
		return this.num ;
	}
}
