
module Csc102_Project {
	requires java.desktop;
	
}